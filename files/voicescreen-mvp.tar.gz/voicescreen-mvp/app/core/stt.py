"""Speech-to-text via Yandex SpeechKit.

Uses synchronous recognition for MVP. Streaming recognition will be added
when we have stable audio chunks coming from Mango WebSocket.
"""

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

log = structlog.get_logger(__name__)

YC_STT_URL = "https://stt.api.cloud.yandex.net/speech/v1/stt:recognize"


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=5))
async def transcribe(audio_bytes: bytes, sample_rate: int = 8000) -> str:
    """Transcribe audio chunk to text.

    audio_bytes: LPCM 16-bit mono audio.
    """
    import httpx

    params = {
        "folderId": settings.yc_folder_id,
        "lang": "ru-RU",
        "format": "lpcm",
        "sampleRateHertz": str(sample_rate),
        "topic": settings.yc_stt_model,
    }
    headers = {"Authorization": f"Api-Key {settings.yc_api_key}"}

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(
            YC_STT_URL,
            params=params,
            headers=headers,
            content=audio_bytes,
        )
        response.raise_for_status()
        data = response.json()

    text = data.get("result", "")
    log.debug("stt_result", chars=len(text))
    return text
