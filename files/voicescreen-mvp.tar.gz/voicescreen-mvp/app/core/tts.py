"""Text-to-speech via Yandex SpeechKit."""

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

log = structlog.get_logger(__name__)

YC_TTS_URL = "https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize"


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=5))
async def synthesize(text: str, sample_rate: int = 8000) -> bytes:
    """Synthesize speech from text. Returns LPCM audio bytes."""
    import httpx

    data = {
        "text": text,
        "lang": "ru-RU",
        "voice": settings.yc_tts_voice,
        "folderId": settings.yc_folder_id,
        "format": "lpcm",
        "sampleRateHertz": str(sample_rate),
    }
    headers = {"Authorization": f"Api-Key {settings.yc_api_key}"}

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.post(YC_TTS_URL, headers=headers, data=data)
        response.raise_for_status()

    audio = response.content
    log.debug("tts_result", text_chars=len(text), audio_bytes=len(audio))
    return audio
