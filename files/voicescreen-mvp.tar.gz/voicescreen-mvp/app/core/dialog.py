"""Dialog orchestrator — the heart of the product.

State machine that runs one candidate call from greeting to closing.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import structlog

from app.core.llm import Message, chat_complete
from app.core.scenario import Question, Scenario

log = structlog.get_logger(__name__)

PROMPTS_DIR = Path(__file__).parent / "prompts"


@dataclass
class DialogState:
    """Persistent state of a single call."""

    scenario: Scenario
    answers: dict[str, str] = field(default_factory=dict)
    current_question_idx: int = 0
    reprompt_count: int = 0
    consent_given: bool | None = None
    decision: Literal["pending", "passed", "failed", "hangup"] = "pending"
    history: list[Message] = field(default_factory=list)

    @property
    def current_question(self) -> Question | None:
        if self.current_question_idx >= len(self.scenario.questions):
            return None
        return self.scenario.questions[self.current_question_idx]

    @property
    def is_done(self) -> bool:
        return self.decision != "pending" or self.current_question is None


def load_system_prompt() -> str:
    """Load dialog system prompt from markdown file."""
    path = PROMPTS_DIR / "dialog_system.md"
    if not path.exists():
        return _fallback_system_prompt()
    return path.read_text(encoding="utf-8")


def _fallback_system_prompt() -> str:
    return (
        "Ты — голосовой помощник по имени Алёна, работающий по поручению HR-отдела. "
        "Твоя задача — задавать вопросы анкеты строго по порядку и кратко подтверждать "
        "полученные ответы. Говори вежливо, кратко, без воды. "
        "Если кандидат явно отказывается общаться — попрощайся и положи трубку."
    )


def build_initial_greeting(scenario: Scenario) -> str:
    """First agent utterance. Must contain consent notice (152-ФЗ)."""
    return f"{scenario.greeting} {scenario.consent_prompt}"


async def classify_consent(user_text: str) -> bool:
    """Is user's reply to consent prompt a yes or a no?"""
    text = user_text.lower().strip()
    negative = ["нет", "не хочу", "не буду", "отказываюсь", "против", "не согласен"]
    for n in negative:
        if n in text:
            return False
    return True


async def classify_answer(question: Question, user_text: str) -> str:
    """Normalise free-form user text into a canonical answer.

    For yes_no → "yes"/"no"/"unclear".
    For choice → matched choice or "unclear".
    For free_form → raw text.
    """
    text = user_text.lower().strip()

    if question.type == "yes_no":
        if any(w in text for w in ["да", "конечно", "верно", "есть", "имею"]):
            return "yes"
        if any(w in text for w in ["нет", "не ", "отсутствует", "нету"]):
            return "no"
        return "unclear"

    if question.type == "choice":
        for choice in question.choices:
            if choice.lower() in text:
                return choice
        return "unclear"

    # free_form / numeric — LLM extraction (MVP: return as-is)
    return user_text.strip()


async def next_agent_reply(state: DialogState, user_text: str | None) -> str:
    """Compute the next agent utterance given current state and last user reply.

    Returns the text to be synthesised and played to the candidate.
    """
    # 1. Consent handling
    if state.consent_given is None:
        if user_text is None:
            return build_initial_greeting(state.scenario)
        state.consent_given = await classify_consent(user_text)
        if not state.consent_given:
            state.decision = "hangup"
            return "Понял вас, хорошего дня."
        # Proceed to first question
        q = state.current_question
        assert q is not None
        return f"Спасибо. {q.text}"

    # 2. Answering questions
    q = state.current_question
    if q is None:
        state.decision = "passed" if state.decision == "pending" else state.decision
        return state.scenario.closing

    if user_text is None:
        return q.text  # repeat current question

    answer = await classify_answer(q, user_text)

    if answer == "unclear":
        state.reprompt_count += 1
        if state.reprompt_count >= 2:
            # move on after 2 failed attempts
            state.answers[q.id] = "unclear"
            state.reprompt_count = 0
            state.current_question_idx += 1
            next_q = state.current_question
            if next_q is None:
                state.decision = "passed"
                return state.scenario.closing
            return f"Хорошо, двигаемся дальше. {next_q.text}"
        return f"Извините, не расслышала. {q.text}"

    # Got a clear answer
    state.answers[q.id] = answer
    state.reprompt_count = 0

    # Check fail condition
    if answer in q.fail_if:
        state.decision = "failed"
        return state.scenario.closing

    # Move to next question
    state.current_question_idx += 1
    next_q = state.current_question
    if next_q is None:
        state.decision = "passed"
        return state.scenario.closing
    return next_q.text


def compute_final_score(state: DialogState) -> int:
    """Simple MVP scoring: count non-unclear, non-failed answers."""
    if state.decision == "failed":
        return 0
    if state.decision == "hangup":
        return 0
    return sum(
        1
        for ans in state.answers.values()
        if ans not in ("unclear", "no")
    )
