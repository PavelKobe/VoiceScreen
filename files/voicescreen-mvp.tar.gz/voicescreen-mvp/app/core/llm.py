"""Unified LLM client. Dispatches to OpenAI / Anthropic / YandexGPT."""

from typing import Literal, TypedDict

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

log = structlog.get_logger(__name__)


class Message(TypedDict):
    role: Literal["system", "user", "assistant"]
    content: str


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=5))
async def chat_complete(
    messages: list[Message],
    temperature: float = 0.3,
    max_tokens: int = 200,
) -> str:
    """Single completion call.

    Short max_tokens by default — agent replies should be concise.
    """
    match settings.llm_provider:
        case "openai":
            return await _openai_chat(messages, temperature, max_tokens)
        case "anthropic":
            return await _anthropic_chat(messages, temperature, max_tokens)
        case "yandex":
            return await _yandex_chat(messages, temperature, max_tokens)
        case _:
            raise ValueError(f"Unknown LLM provider: {settings.llm_provider}")


async def _openai_chat(
    messages: list[Message], temperature: float, max_tokens: int
) -> str:
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=settings.openai_api_key)
    response = await client.chat.completions.create(
        model=settings.openai_model,
        messages=messages,  # type: ignore[arg-type]
        temperature=temperature,
        max_tokens=max_tokens,
    )
    content = response.choices[0].message.content or ""
    log.debug(
        "openai_response",
        tokens_in=response.usage.prompt_tokens if response.usage else 0,
        tokens_out=response.usage.completion_tokens if response.usage else 0,
    )
    return content


async def _anthropic_chat(
    messages: list[Message], temperature: float, max_tokens: int
) -> str:
    from anthropic import AsyncAnthropic

    client = AsyncAnthropic(api_key=settings.anthropic_api_key)

    # Anthropic separates system messages
    system = ""
    conv = []
    for m in messages:
        if m["role"] == "system":
            system = m["content"]
        else:
            conv.append(m)

    response = await client.messages.create(
        model="claude-haiku-4-5-20251001",
        system=system,
        messages=conv,  # type: ignore[arg-type]
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return response.content[0].text  # type: ignore[union-attr]


async def _yandex_chat(
    messages: list[Message], temperature: float, max_tokens: int
) -> str:
    """YandexGPT via REST API. Implement when needed for РФ-контур clients."""
    raise NotImplementedError("YandexGPT integration pending")
