"""Load and parse YAML scenarios (screening questionnaires)."""

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field


class Question(BaseModel):
    id: str
    text: str
    type: Literal["yes_no", "choice", "free_form", "numeric"]
    choices: list[str] = Field(default_factory=list)
    required: bool = True
    fail_if: list[str] = Field(default_factory=list)
    """If the normalised answer matches any of these, candidate fails."""


class Scenario(BaseModel):
    id: str
    title: str
    greeting: str
    consent_prompt: str
    questions: list[Question]
    closing: str
    pass_threshold: int = Field(default=0, ge=0)
    """Minimum score to pass. 0 means pass if not failed outright."""


def load_scenario(name: str, base_dir: Path | None = None) -> Scenario:
    """Load a scenario from scenarios/<name>.yaml."""
    base_dir = base_dir or Path(__file__).parent.parent.parent / "scenarios"
    path = base_dir / f"{name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Scenario not found: {path}")

    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    return Scenario(**data)
