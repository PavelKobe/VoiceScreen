"""Application settings loaded from environment variables."""

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Centralised settings. Never hardcode secrets."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Core
    app_env: Literal["dev", "staging", "prod"] = "dev"
    log_level: str = "INFO"
    secret_key: str = "change-me-in-prod"

    # Database
    database_url: str
    redis_url: str

    # Yandex Cloud
    yc_folder_id: str = ""
    yc_api_key: str = ""
    yc_stt_model: str = "general"
    yc_tts_voice: str = "alena"
    yc_storage_bucket: str = "voicescreen-recordings"
    yc_storage_access_key: str = ""
    yc_storage_secret_key: str = ""

    # LLM
    llm_provider: Literal["openai", "yandex", "anthropic"] = "openai"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    yandex_gpt_api_key: str = ""

    # Mango Office
    mango_api_key: str = ""
    mango_api_salt: str = ""
    mango_webhook_secret: str = ""
    mango_from_number: str = ""

    # Telegram
    telegram_bot_token: str = ""

    # Call scheduling
    call_working_hours_start: int = 9
    call_working_hours_end: int = 21
    call_max_retries: int = 3
    call_retry_interval_minutes: int = 120

    # Safety limits
    daily_call_limit: int = Field(default=500, description="Max outbound calls per day")
    daily_llm_token_limit: int = Field(default=1_000_000)


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
