"""Telegram bot for clients. Entry point: `python -m app.bot.bot`."""

import asyncio

import structlog
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message

from app.config import settings

log = structlog.get_logger(__name__)

dp = Dispatcher()


@dp.message(Command("start"))
async def cmd_start(message: Message) -> None:
    await message.answer(
        "👋 Добро пожаловать в VoiceScreen.\n\n"
        "Я помогаю автоматизировать первичный скрининг кандидатов.\n\n"
        "Доступные команды:\n"
        "/upload — загрузить список кандидатов (CSV)\n"
        "/vacancies — мои вакансии\n"
        "/report — отчёт за сегодня\n"
        "/settings — настройки\n\n"
        "Чтобы начать работу, напишите /register"
    )


@dp.message(Command("register"))
async def cmd_register(message: Message) -> None:
    # TODO: создать запись Client, выдать API-ключ, привязать tg_chat_id
    await message.answer(
        "Регистрация пока в разработке.\n"
        f"Ваш Telegram ID: `{message.chat.id}`\n"
        "Отправьте его администратору для ручного подключения.",
        parse_mode="Markdown",
    )


@dp.message(Command("report"))
async def cmd_report(message: Message) -> None:
    # TODO: получить Client по tg_chat_id, собрать статистику за день
    await message.answer(
        "📊 Отчёт за сегодня\n\n"
        "Звонков: 0\n"
        "Прошли скрининг: 0\n"
        "Не прошли: 0\n"
        "Не дозвонились: 0\n\n"
        "_Данные появятся после первых звонков_",
        parse_mode="Markdown",
    )


@dp.message(F.document)
async def handle_document(message: Message) -> None:
    """Accept CSV uploads with candidates."""
    # TODO: скачать файл, распарсить, создать Candidate records, поставить звонки
    await message.answer(
        "Файл получен. Обработка загрузки будет добавлена в ближайшем релизе."
    )


async def main() -> None:
    if not settings.telegram_bot_token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not set")

    bot = Bot(token=settings.telegram_bot_token)
    log.info("telegram_bot_starting")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
