"""VoiceScreen — AI voice screening agent for mass hiring."""

__version__ = "0.1.0"
