# CLAUDE.md — app/

Основное приложение. Монолит на FastAPI.

## Структура

| Каталог | За что отвечает |
|---|---|
| `api/` | HTTP-роутеры (webhooks от Mango, health-checks, API для кабинета) |
| `core/` | Ядро диалога: оркестратор, STT, LLM, TTS, промпты |
| `telephony/` | Обёртки над телефонными API (Mango сейчас, возможно Novofon потом) |
| `db/` | SQLAlchemy-модели, сессии, репозитории |
| `workers/` | Celery-воркеры для исходящих звонков, обработки записей, отчётов |
| `bot/` | Telegram-бот для клиентов (загрузка кандидатов, получение отчётов) |

## Точки входа

- `app.main:app` — FastAPI-приложение.
- `app.workers.celery_app:celery` — Celery.
- `app.bot.bot:main` — Telegram-бот (запускается отдельным процессом).

## Конфигурация

Единственный источник правды — `app/config.py` (pydantic-settings). Читает из `.env` + переменных окружения.

```python
from app.config import settings
```

**Не** использовать `os.getenv()` напрямую в коде — всегда через `settings`.

## Dependency Injection

FastAPI зависимости:
- `get_db()` — async SQLAlchemy session
- `get_redis()` — Redis клиент
- `get_current_client()` — аутентификация клиента API (по API-ключу)

## Логирование

```python
import structlog
log = structlog.get_logger(__name__)

log.info("call_started", call_id=call.id, candidate_phone=phone_masked)
```

- Всегда структурированное, ключ-значение.
- Телефоны маскировать (`phone_masked = phone[:2] + "***" + phone[-2:]`) в логах.
- Уровни: `debug` (dev), `info` (production), `warning` (восстановимые ошибки), `error` (не восстановимые).

## Что делать при добавлении новой фичи

1. Если это новая интеграция с внешним API — в соответствующий каталог (`core/` для ML, `telephony/` для звонков).
2. Модель БД — `db/models.py`, миграция через Alembic.
3. HTTP-эндпоинт — `api/`, подключить к `main.py`.
4. Фоновая задача — `workers/tasks.py`.
5. Тесты — `tests/` в корне репозитория (зеркалит структуру `app/`).
