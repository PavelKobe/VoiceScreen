# CLAUDE.md — app/api/

HTTP-слой: роутеры FastAPI.

## Файлы

- `health.py` — `/health` и `/ready`. Не добавляй сюда ничего бизнес-логики.
- `webhooks.py` — входящие webhook'и от телефонии (Mango). Здесь критична безопасность (HMAC-подпись).

## Правила

1. **Роутер делает только маршрутизацию.** Бизнес-логика — в `app/core/` или через Celery-задачу.
2. **Webhook'и — всегда с проверкой подписи.** Никаких «авось». См. `app/telephony/mango.py:verify_signature`.
3. **Длинные операции — через Celery.** Webhook должен отвечать за <500ms, иначе Mango начнёт ретраить.
4. **Валидация входных данных — только через Pydantic-модели**, не парсить JSON руками.
5. **Никаких `time.sleep()` или синхронного I/O** в async-хендлерах.

## Паттерн webhook'а

```python
@router.post("/mango/call-event")
async def mango_call_event(
    request: Request,
    payload: MangoCallEvent,
    db: AsyncSession = Depends(get_db),
) -> dict[str, str]:
    # 1. Проверить подпись
    body = await request.body()
    verify_mango_signature(body, request.headers.get("X-Signature"))

    # 2. Быстро сохранить событие
    await save_raw_event(db, payload)

    # 3. Поставить обработку в очередь
    process_call_event.delay(payload.call_id)

    # 4. Вернуть 200 как можно быстрее
    return {"status": "accepted"}
```

## Что не делать

- Не импортировать Celery-задачи как обычные функции — только `.delay()`.
- Не возвращать внутренние ID БД напрямую. Использовать UUID, чтобы не раскрывать инкременты.
- Не ставить `print()` отладку. `structlog`.
