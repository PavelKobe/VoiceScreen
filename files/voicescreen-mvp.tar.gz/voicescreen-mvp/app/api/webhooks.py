"""Incoming webhooks from telephony providers."""

import structlog
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from app.telephony.mango import verify_mango_signature

log = structlog.get_logger(__name__)
router = APIRouter()


class MangoCallEvent(BaseModel):
    """Event from Mango Office (simplified)."""

    call_id: str
    event: str  # "dial" | "answered" | "hangup" | ...
    from_number: str
    to_number: str
    timestamp: int


@router.post("/mango/call-event")
async def mango_call_event(
    request: Request,
    payload: MangoCallEvent,
) -> dict[str, str]:
    """Accept call state changes from Mango.

    Must respond in <500ms to avoid retries.
    """
    body = await request.body()
    signature = request.headers.get("X-Signature", "")

    if not verify_mango_signature(body, signature):
        log.warning("invalid_webhook_signature", signature=signature[:10])
        raise HTTPException(status_code=401, detail="Invalid signature")

    log.info(
        "mango_event_received",
        call_id=payload.call_id,
        event=payload.event,
    )

    # TODO: поставить обработку в Celery
    # process_mango_event.delay(payload.model_dump())

    return {"status": "accepted"}


@router.post("/mango/media-stream")
async def mango_media_stream(request: Request) -> dict[str, str]:
    """Receive audio stream chunks for real-time STT.

    Actual implementation will use WebSocket for low latency.
    Placeholder for now.
    """
    return {"status": "not_implemented"}
