"""Health and readiness probes."""

from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/ready")
async def ready() -> dict[str, str]:
    # TODO: добавить проверку подключения к БД и Redis
    return {"status": "ready"}
