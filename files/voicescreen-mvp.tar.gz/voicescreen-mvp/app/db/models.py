"""SQLAlchemy ORM models."""

import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Enum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        default=utcnow, onupdate=utcnow, nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(default=None, nullable=True)


class CallStatus(str, enum.Enum):
    scheduled = "scheduled"
    dialing = "dialing"
    in_progress = "in_progress"
    completed = "completed"
    failed = "failed"
    no_answer = "no_answer"
    refused = "refused"


class CallDecision(str, enum.Enum):
    pass_ = "pass"
    fail = "fail"
    incomplete = "incomplete"


class Client(Base, TimestampMixin):
    __tablename__ = "clients"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    tg_chat_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    tariff: Mapped[str] = mapped_column(String(50), default="trial")
    api_key: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)

    vacancies: Mapped[list["Vacancy"]] = relationship(back_populates="client")


class Vacancy(Base, TimestampMixin):
    __tablename__ = "vacancies"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("clients.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    scenario_name: Mapped[str] = mapped_column(String(100), nullable=False)

    client: Mapped["Client"] = relationship(back_populates="vacancies")
    candidates: Mapped[list["Candidate"]] = relationship(back_populates="vacancy")


class Candidate(Base, TimestampMixin):
    __tablename__ = "candidates"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    vacancy_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("vacancies.id"), nullable=False)
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    phone: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    source: Mapped[str | None] = mapped_column(String(50), nullable=True)

    vacancy: Mapped["Vacancy"] = relationship(back_populates="candidates")
    calls: Mapped[list["Call"]] = relationship(back_populates="candidate")


class Call(Base, TimestampMixin):
    __tablename__ = "calls"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    candidate_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("candidates.id"), nullable=False)
    mango_call_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    status: Mapped[CallStatus] = mapped_column(
        Enum(CallStatus), default=CallStatus.scheduled, nullable=False
    )
    decision: Mapped[CallDecision | None] = mapped_column(Enum(CallDecision), nullable=True)
    score: Mapped[int | None] = mapped_column(nullable=True)
    duration_seconds: Mapped[int | None] = mapped_column(nullable=True)
    recording_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    answers: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    failure_reason: Mapped[str | None] = mapped_column(String(200), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(nullable=True)
    ended_at: Mapped[datetime | None] = mapped_column(nullable=True)

    candidate: Mapped["Candidate"] = relationship(back_populates="calls")
    turns: Mapped[list["CallTurn"]] = relationship(back_populates="call", order_by="CallTurn.sequence")


class CallTurn(Base):
    __tablename__ = "call_turns"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    call_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("calls.id"), nullable=False)
    sequence: Mapped[int] = mapped_column(nullable=False)
    speaker: Mapped[str] = mapped_column(String(20), nullable=False)  # "agent" | "candidate"
    text: Mapped[str] = mapped_column(Text, nullable=False)
    audio_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(default=utcnow, nullable=False)

    call: Mapped["Call"] = relationship(back_populates="turns")
