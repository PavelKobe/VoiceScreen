"""Mango Office API client.

Docs: https://www.mango-office.ru/support/api/
"""

import hashlib
import hmac
import json
import time

import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

log = structlog.get_logger(__name__)

MANGO_API_BASE = "https://app.mango-office.ru/vpbx"


def _sign_request(json_payload: str) -> str:
    """Mango signs requests with sha256(api_key + json + api_salt)."""
    raw = (settings.mango_api_key + json_payload + settings.mango_api_salt).encode()
    return hashlib.sha256(raw).hexdigest()


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
async def initiate_call(to_number: str, extension: str = "") -> str:
    """Start an outbound call.

    Returns Mango's call_id.
    """
    payload = {
        "command_id": f"voicescreen_{int(time.time() * 1000)}",
        "from": {"extension": extension, "number": settings.mango_from_number},
        "to_number": to_number,
        "line_number": settings.mango_from_number,
    }
    json_payload = json.dumps(payload)
    signature = _sign_request(json_payload)

    data = {
        "vpbx_api_key": settings.mango_api_key,
        "sign": signature,
        "json": json_payload,
    }

    async with httpx.AsyncClient(timeout=15.0) as client:
        response = await client.post(f"{MANGO_API_BASE}/commands/callback", data=data)
        response.raise_for_status()
        result = response.json()

    call_id = result.get("call_id", "")
    log.info("call_initiated", to_masked=_mask(to_number), call_id=call_id)
    return call_id


def verify_mango_signature(body: bytes, signature: str) -> bool:
    """Verify webhook signature from Mango."""
    if not signature or not settings.mango_webhook_secret:
        return False

    expected = hmac.new(
        key=settings.mango_webhook_secret.encode(),
        msg=body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature)


def _mask(phone: str) -> str:
    if len(phone) < 6:
        return "***"
    return f"{phone[:2]}***{phone[-2:]}"
