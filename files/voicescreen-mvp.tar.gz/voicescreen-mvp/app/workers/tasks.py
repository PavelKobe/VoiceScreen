"""Celery tasks for call lifecycle management."""

import asyncio
from typing import Any

import structlog

from app.workers.celery_app import celery

log = structlog.get_logger(__name__)


def run_async(coro: Any) -> Any:
    """Helper to run async code from sync Celery task."""
    return asyncio.get_event_loop().run_until_complete(coro)


@celery.task(name="app.workers.tasks.originate_call", bind=True, max_retries=3)
def originate_call(self: Any, call_id: str) -> dict[str, str]:
    """Initiate an outbound call via Mango for the given Call record."""
    log.info("task_originate_call_started", call_id=call_id)

    async def _run() -> dict[str, str]:
        from app.db.session import SessionLocal
        from app.telephony.mango import originate_call as mango_originate
        from sqlalchemy import select
        from app.db.models import Call, Candidate, CallStatus

        async with SessionLocal() as db:
            call = await db.get(Call, call_id)
            if call is None:
                log.warning("call_not_found", call_id=call_id)
                return {"status": "not_found"}

            candidate = await db.get(Candidate, call.candidate_id)
            if candidate is None:
                return {"status": "candidate_not_found"}

            mango_call_id = await mango_originate(candidate.phone)
            call.mango_call_id = mango_call_id
            call.status = CallStatus.dialing
            await db.commit()

            return {"status": "dialing", "mango_call_id": mango_call_id}

    try:
        return run_async(_run())
    except Exception as exc:
        log.exception("task_originate_call_failed", call_id=call_id)
        raise self.retry(exc=exc, countdown=60 * 2**self.request.retries) from exc


@celery.task(name="app.workers.tasks.process_call_event")
def process_call_event(mango_call_id: str, event: str) -> dict[str, str]:
    """Handle a Mango webhook event (dial/answered/hangup)."""
    log.info("task_process_event", mango_call_id=mango_call_id, event=event)
    # TODO: обновить статус Call, при hangup запустить finalize_call
    return {"status": "accepted"}


@celery.task(name="app.workers.tasks.finalize_call")
def finalize_call(call_id: str) -> dict[str, str]:
    """After hangup: fetch recording, compute score, notify client."""
    log.info("task_finalize_started", call_id=call_id)
    # TODO: получить запись из Mango, залить в Object Storage,
    #       вычислить итоговый score, отправить уведомление клиенту
    return {"status": "finalized", "call_id": call_id}


@celery.task(name="app.workers.tasks.schedule_pending_calls")
def schedule_pending_calls() -> dict[str, int]:
    """Periodic task: queue calls that are due to be made (9:00–21:00 local)."""

    async def _run() -> dict[str, int]:
        from datetime import datetime, timezone
        from sqlalchemy import select
        from app.config import settings
        from app.db.models import Call, CallStatus
        from app.db.session import SessionLocal

        now = datetime.now(timezone.utc)
        hour = now.hour  # TODO: учесть таймзону кандидата
        if not (settings.call_working_hours_start <= hour < settings.call_working_hours_end):
            return {"queued": 0, "reason": "outside_working_hours"}

        async with SessionLocal() as db:
            result = await db.execute(
                select(Call).where(Call.status == CallStatus.scheduled).limit(50)
            )
            scheduled = result.scalars().all()
            for call in scheduled:
                originate_call.delay(str(call.id))

            return {"queued": len(scheduled)}

    return run_async(_run())


@celery.task(name="app.workers.tasks.send_daily_reports")
def send_daily_reports() -> dict[str, int]:
    """Send end-of-day summary to each active client in Telegram."""
    log.info("task_daily_reports_started")
    # TODO: для каждого клиента с tg_chat_id собрать статистику за день и отправить
    return {"sent": 0}
