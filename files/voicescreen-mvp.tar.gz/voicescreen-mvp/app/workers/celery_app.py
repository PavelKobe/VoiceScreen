"""Celery application configuration."""

from celery import Celery

from app.config import settings

celery = Celery(
    "voicescreen",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["app.workers.call_tasks"],
)

celery.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="Europe/Moscow",
    enable_utc=True,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "app.workers.call_tasks.initiate_outbound_call": {"queue": "calls"},
        "app.workers.call_tasks.process_call_event": {"queue": "calls"},
        "app.workers.call_tasks.generate_daily_report": {"queue": "reports"},
    },
    beat_schedule={
        "schedule-pending-calls": {
            "task": "app.workers.call_tasks.schedule_pending_calls",
            "schedule": 300.0,  # every 5 min
        },
    },
)
