"""Test a full call flow from the CLI.

Usage:
    python -m scripts.test_call --phone +79991234567 --scenario courier_screening

What it does:
    1. Loads the scenario YAML.
    2. Originates a call via Mango to the given number.
    3. Logs every turn to stdout.
    4. Saves transcript and recording locally for inspection.

Note: This is a smoke test. It requires all env vars set and Mango webhook
reachable (use ngrok in dev).
"""

import argparse
import asyncio
import sys
from pathlib import Path

import structlog

sys.path.insert(0, str(Path(__file__).parent.parent))

from app.core.scenario import load_scenario
from app.telephony.mango import originate_call

log = structlog.get_logger(__name__)


async def main(phone: str, scenario_name: str) -> None:
    scenario = load_scenario(scenario_name)
    log.info("scenario_loaded", id=scenario.id, questions=len(scenario.questions))
    log.info("greeting_preview", text=scenario.greeting.strip())

    call_id = await originate_call(phone)
    log.info("call_started", mango_call_id=call_id, phone=phone)

    print("\n" + "=" * 60)
    print(f"Call initiated. Mango call_id: {call_id}")
    print(f"Target: {phone}")
    print(f"Scenario: {scenario.title}")
    print("=" * 60)
    print("\nWatch logs for the call progress. Recording will be available")
    print("in Yandex Object Storage after the call completes.\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Trigger a test call")
    parser.add_argument("--phone", required=True, help="Phone number, e.g. +79991234567")
    parser.add_argument("--scenario", required=True, help="Scenario name from /scenarios/")
    args = parser.parse_args()

    asyncio.run(main(args.phone, args.scenario))
